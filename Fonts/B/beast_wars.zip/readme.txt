BeastWars.TTF �1998 Neale Davidson.
All Rights Reserved.

Permission is given by the author to redistribute for 
non-commercial use.  Please include this readme.txt file.

BeastWars.TTF is freeware.

Neale Davidson
neale@iquest.net

For more font fun, visit the Empire Of The Claw:
http://www.mysite.com/empire

