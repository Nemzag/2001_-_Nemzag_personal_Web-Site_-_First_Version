The font contained in this archive is Freeware.
No payment is required for the use of this font.  It's free!
Commercial use?  Sure, but a donation or a product sample would be
appreciated.

$40 US is the usual amount per font for commercial use but any amount is appreciated.

I make all the fonts (over 210 of them) on my web page and
they're all free.

The page is called Larabie Fonts
It can be found at various mirror sites.

try:
http://come.to/larabiefonts
www.swankarmy.net/larabiefonts

I've provided the world with over a hundred and eighty free fonts,
so if you'd like to make a donation I'd be more than happy to accept it.

No donation is too small!  Music and artwork are good too.
If you have some CD's you're not listening to anymore, send 'em along!

Send anything at all to

Ray Larabie
61 Wesley Ave.
Port Credit
Ontario, CANADA
L5H 2M8

If you decide to send a cheque (that's how we spell it in Canada)
make it payable to Ray Larabie.  If you want to double check the address
have a look at the donation section on any of my webpages.

Canadian or US funds?  Any funds are fine with me.
Whatever's easy for you.


Ray Larabie
drowsy@cheerful.com
or...
rlarabie@hotmail.com

-------------------------------
Larabie Fonts End-user license agreement software product from Larabie Fonts
---------------------------------------------------

SOFTWARE PRODUCT LICENSE

The SOFTWARE PRODUCT is protected by copyright laws and international copyright treaties,
as well as other intellectual property laws and treaties. The SOFTWARE PRODUCT is licensed,
not sold.

1. GRANT OF LICENSE. This document grants you the following rights:

- Installation and Use. You may install and use an unlimited number of copies of the
SOFTWARE PRODUCT.

- Reproduction and Distribution. You may reproduce and distribute an unlimited number of
copies of the SOFTWARE PRODUCT;  provided that each copy shall be a true and complete copy,
including all copyright and trademark notices (if applicable) , and shall be accompanied by
a copy of this text file.  Copies of the SOFTWARE PRODUCT may not be distributed for profit
either on a standalone basis or included as part of your own product unless by prior
permission of Larabie Fonts.

2. DESCRIPTION OF OTHER RIGHTS AND LIMITATIONS. 

- Restrictions on Alteration.  You may not rename, edit or create any derivative works from
the SOFTWARE PRODUCT, other than subsetting when embedding them in documents unless you have
permission from Larabie Fonts.

LIMITED WARRANTY
NO WARRANTIES. Larabie Fonts expressly disclaims any warranty for the SOFTWARE PRODUCT. The
SOFTWARE PRODUCT and any related documentation is provided "as is" without warranty of any
kind, either express or implied, including, without limitation, the implied warranties or
merchantability, fitness for a particular purpose, or noninfringement. The entire risk
arising out of use or performance of the SOFTWARE PRODUCT remains with you.

NO LIABILITY FOR CONSEQUENTIAL DAMAGES. In no event shall Larabie Fonts be liable for any
damages whatsoever (including, without limitation, damages for loss of business profits,
business interruption, loss of business information, or any other pecuniary loss) arising
out of the use of or inability to use this product, even if Larabie Fonts has been advised
of the possibility of such damages.

3. MISCELLANEOUS

Should you have any questions concerning this document, or if you desire to contact
Larabie Fonts for any reason, please contact rlarabie@hotmail.com , or write: Ray Larabie,
61 Wesley Ave. Mississauga, ON Canada L5H 2M8