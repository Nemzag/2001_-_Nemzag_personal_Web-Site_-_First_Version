This font is free but if you would like to send me money anyway, I won't say no. You can give this font to your friends or upload it to your favorite bulletin board as long as you keep this text file with it.  
If you are a commercial enterprise selling disks of shareware and freeware, you may not distribute this font without my permission.
If you use it to something nice, like a recordcover or a flyer, please send me a copy.......

Thomas Rogerstam 
Stora Nygatan 27c211 37 MalmSwedengud@disney-world.com