The enclosed font(Orient) was created by me, Christopher Gamble.  This is a more complete font than Green Dinosaur.  It's still limited to upper case, but I've included all the characters on the keyboard.  If you like this font, please feel free to send a small donation to:

Christopher Gamble
5333 Glenville Circle
Virginia Beach, VA  23464-5441

This is the second font I've created, and would enjoy creating more.  If you have any comments or suggestions, please feel free to email me at:

Grn_Dino@msn.com

Also, when I create more fonts they will be posted on my web site.  Please feel free to vist my site at:

http://www.angelfire.com/va/grndino
