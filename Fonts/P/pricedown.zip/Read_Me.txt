The font contained in this archive is Freeware.
No payment is required for the use of this font.  It's free!
Commercial or personal use?  It doesn't matter, it's free.

I make all the fonts (over 113 of them) on my web page and
they're all free.

The page is called Larabie Fonts
It can be found at various mirror sites.

try:
www.delirium.com/larabiefonts
www.swankarmy.net/larabiefonts
www.goldenapple.com/larabiefonts
highland.mit.edu/larabiefonts
web.mit.edu/zudark/larabiefonts

if all else fails there might be some links at
www.globalserve.net/~rlarabie/freefont.htm

I've provided the world with over a hundred and thirteen free fonts,
so if you'd like to make a donation I'd be more than happy to accept it.

No donation is too small!  Music and artwork are good too.
If you have some CD's you're not listening to anymore, send 'em along!

Send anything at all to

Ray Larabie
61 Wesley Ave.
Port Credit
Ontario, CANADA
L5H 2M8

If you decide to send a cheque (that's how we spell it in Canada)
make it payable to Ray Larabie.

Canadian or US funds?  Any funds are fine with me.
Whatever's easy for you.


Ray Larabie
droswy@cheerful.com
or...
rlarabie@swankarmy.net
rlarabie@stealthmail.com
rlarabie@hotmail.com